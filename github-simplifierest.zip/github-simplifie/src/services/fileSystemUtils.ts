import { readDir } from "@tauri-apps/plugin-fs";

/**
 * Explore récursivement un dossier réel du disque (chemin obtenu via
 * l'event natif Tauri onDragDropEvent) et renvoie les chemins relatifs
 * de tous les fichiers qu'il contient. Contrairement à l'ancienne
 * approche basée sur l'API File du navigateur, on a ici un vrai accès
 * disque : pas besoin de lire le contenu des fichiers pour l'analyse,
 * juste leur emplacement.
 */
export async function listerCheminsRelatifs(cheminAbsolu: string): Promise<string[]> {
  const resultats: string[] = [];

  async function explorer(sousChemin: string, prefixeRelatif: string): Promise<void> {
    const entrees = await readDir(sousChemin);
    for (const entree of entrees) {
      const cheminEnfant = `${sousChemin}/${entree.name}`;
      const relatifEnfant = prefixeRelatif ? `${prefixeRelatif}/${entree.name}` : entree.name ?? "";
      if (entree.isDirectory) {
        await explorer(cheminEnfant, relatifEnfant);
      } else {
        resultats.push(relatifEnfant);
      }
    }
  }

  await explorer(cheminAbsolu, "");
  return resultats;
}
